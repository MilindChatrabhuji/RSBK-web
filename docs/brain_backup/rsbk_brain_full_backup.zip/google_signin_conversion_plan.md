# 🚀 RSBK Online: Master Plan for Maximum Google Sign-In Conversion

## Executive Diagnosis: Why Visitors Bounce Without Registering

Based on an analysis of [RSBK Online](https://rsbk-online.web.app) (`rsbk-online.web.app`), visitors currently land on the homepage and leave without signing in for **five fundamental psychological and design reasons**:

```mermaid
flowchart TD
    A["Visitor Lands on Homepage"] --> B{"Current Obstacles"}
    B -->|"1. Invisible Sign-In"| C["Google Sign-In button is tiny & hidden in top-right navbar"]
    B -->|"2. Perceived Paywall Fear"| D["'Trial' and 'Wallet' terms make users think it's a paid trap"]
    B -->|"3. Zero Value Preview"| E["Subpages show cold locked gate instead of a tempting sneak peek"]
    B -->|"4. No Google One Tap"| F["Visitor isn't greeted with a 1-tap 'Continue as [Name]' native prompt"]
    B -->|"5. No Urgency / Hook"| G["No lead magnet (e.g., Free NCISM Question Bank / Notes Download)"]
    C & D & E & F & G --> H["Visitor Leaves (Bounce Rate > 85%)"]
```

---

## 6 Strategic Pillars to Maximize Google Sign-In Registration

### Pillar 1: Google One Tap (GIS) Integration (The #1 Conversion Booster)
> [!IMPORTANT]
> **What is Google One Tap?** 
> It is Google's native identity prompt. When any visitor opens RSBK Online on an Android phone or Chrome desktop, a small native card automatically appears:
> *"Continue to RSBK Online as Dr. [Name] ([email@gmail.com])"* with a single blue **Continue** button.
- **Conversion Impact**: Increases sign-ins by **300% to 500%** because the user does **not** have to search for a login button or leave their reading flow.
- **Implementation**: Integrate the Google Identity Services (`google.accounts.id.initialize` & `google.accounts.id.prompt()`) with Firebase credential exchange in [`public/script.js`](file:///d:/Dr%20Milind%20Chatrabhuji/Books%20Authored%20by%20me/RSBK.web.app/public/script.js).

---

### Pillar 2: High-Converting Hero Section Redesign
Currently, the hero section has an animated marquee ticker that moves continuously and cannot be easily clicked. The main hero lacks a primary Call-to-Action (CTA).

#### Proposed Changes to [`public/index.html`](file:///d:/Dr%20Milind%20Chatrabhuji/Books%20Authored%20by%20me/RSBK.web.app/public/index.html):
1. **Primary Hero Action**: Add a prominent, full-width or large pill button right below the hero subtitle:
   ```html
   <div class="hero-cta-group">
       <button id="heroGoogleSignInBtn" class="btn-hero-google">
           <svg class="google-icon" ...></svg>
           <span>Continue with Google — 100% Free Instant Access</span>
       </button>
       <div class="hero-cta-guarantees">
           <span><ion-icon name="checkmark-circle"></ion-icon> Completely Free</span>
           <span><ion-icon name="checkmark-circle"></ion-icon> 1-Click Sign-In</span>
           <span><ion-icon name="checkmark-circle"></ion-icon> NCISM Aligned</span>
       </div>
   </div>
   ```
2. **Reframe Messaging**:
   - Change *"30-Day Free Trial"* to **"Free Scholar Access: Instant 1-Click Access to All Textbooks, ABQ Question Banks & Teaching Frameworks"**.
   - Ayurvedic students and doctors hesitate if they think their access will be abruptly revoked or billed; highlighting **"100% Free Scholar Account"** eliminates friction.

---

### Pillar 3: "Content Sneak Peek" Model (Soft Gating vs Hard Gating)
Currently, if an unauthenticated user clicks **"For Students"** or **"Books Archive"**, they immediately see a solid locked screen ([`#authGate`](file:///d:/Dr%20Milind%20Chatrabhuji/Books%20Authored%20by%20me/RSBK.web.app/public/script.js#L517-L561)).
This creates immediate disappointment and causes users to bounce.

#### The "Teaser / Peek" Strategy:
- **Show 20% to 30% Free**: Let visitors freely read Module 1, examine sample ABQ questions, or view the table of contents.
- **Blur & Unlock Banner**: At Module 2 or the PDF reader, apply a modern glassmorphic blur:
  > **"Unlock All 15 Modules & PDF Treatises Free"**
  > *"Sign in with Google in 3 seconds to read the full chapter and download sample question banks."*
  > `[ Continue with Google (Free) ]`

This gives the visitor undeniable proof of quality *before* asking them to sign in.

---

### Pillar 4: Floating Sticky Guest Bar (Mobile & Desktop)
Visitors scroll down the homepage reading about Bloom's taxonomy and Miller's pyramid, but the login button stays far behind in the top navbar.
- Add an unobtrusive, floating bottom bar that appears only for unauthenticated users after scrolling 200px:
  - **Left**: *"Join 1,000+ Ayurveda Scholars & Doctors on RSBK Online"*
  - **Right**: `[ Sign in with Google (Free) ]`
- On mobile, this converts thumb-reach into instant 1-tap sign-ins.

---

### Pillar 5: "Lead Magnet" Benefit (Give an Immediate Tangible Reward)
People sign in when there is an immediate payoff.
- **Offer a Free Instant Download or Digital Tool**:
  - Example: *"Sign in with Google to get instant access to the RSBK Practical Training Proforma & Exam Preparation Blueprint."*
  - Place a badge: **"Free for all BAMS & MD/MS Scholars"**.

---

### Pillar 6: Inactivity / Exit-Intent Gentle Nudge
If a visitor is about to close the tab on desktop (cursor leaves the browser window) or has spent 25+ seconds browsing without signing in:
- Show an elegant, non-annoying modal prompt:
  > **"Explore RSBK Online Free"**
  > *"Don't miss out on complete cognitive frameworks, Bloom's pedagogical blueprints, and classical texts curated by Dr. Milind Chatrabhuji."*
  > `[ Sign in with Google ]` &nbsp; `[ Maybe Later ]`

---

## Technical Implementation Roadmap

| Phase | Milestone | Expected Impact | Est. Effort |
| :--- | :--- | :--- | :--- |
| **Phase 1** | **Hero Redesign & Copy Alignment**: Add prominent 1-click Google Sign-In button with "100% Free Scholar Access" badges. | +40% Sign-in Conversion | Quick |
| **Phase 2** | **Google One Tap (GIS)**: Automatic native 1-tap prompt for returning/new Google users on desktop & mobile. | +150% - 300% Conversion | Medium |
| **Phase 3** | **Sticky Guest Bar**: Bottom floating bar across homepage and subpages for unauthenticated visitors. | +30% Mobile Conversions | Quick |
| **Phase 4** | **Content Preview (Soft Gating)**: Allow visitors to see 1-2 free preview modules before showing the sign-in unlocker. | -60% Bounce Rate on Subpages | Medium |
| **Phase 5** | **Lead Magnet / Exit Nudge**: Exam blueprint banner + gentle exit modal. | +20% Conversion of abandoning visitors | Quick |

---

## Recommended Immediate First Step
We can immediately implement **Phase 1 (Hero CTA & Clarity Badges)** and **Phase 3 (Floating Mobile/Desktop Guest Bar)** to instantly convert homepage visitors, followed by **Google One Tap**.
